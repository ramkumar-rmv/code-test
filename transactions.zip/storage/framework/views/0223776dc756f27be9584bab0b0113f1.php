<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Transaction Details</h2>
     <?php $__env->endSlot(); ?>
    <div class="py-6">
        <div class="max-w-md mx-auto p-4 bg-white shadow rounded-2xl space-y-4">
            <p><strong>Summary:</strong> <?php echo e($transaction->summary); ?></p>
            <p><strong>Amount:</strong> $<?php echo e(number_format($transaction->amount, 2)); ?></p>
            <p><strong>Status:</strong> <?php echo e(ucfirst($transaction->status)); ?></p>

            <?php if($transaction->file_attachment): ?>
                <p class="mt-2">
                    <strong>Attachment:</strong>
                    <a href="<?php echo e(asset('storage/' . $transaction->file_attachment)); ?>" target="_blank" class="text-blue-600 underline">
                        View File
                    </a>
                </p>
            <?php endif; ?>

            <a href="<?php echo e(route('dashboard')); ?>" class="inline-block mt-4 text-blue-500 hover:underline">← Back to Dashboard</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\transactions\resources\views/transactions/show.blade.php ENDPATH**/ ?>