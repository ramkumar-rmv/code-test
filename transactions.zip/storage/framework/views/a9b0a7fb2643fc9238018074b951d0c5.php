<div class="bg-white shadow rounded p-4">
    <h2 class="text-lg font-semibold mb-2">Pending Transactions</h2>

    <!--[if BLOCK]><![endif]--><?php if($transactions->count()): ?>
        <ul class="space-y-2">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex justify-between items-center border-b py-2">
                    <div>
                        <p class="text-sm font-medium"><?php echo e($txn->summary); ?></p>
                        <p class="text-xs text-gray-500">Amount: $<?php echo e(number_format($txn->amount, 2)); ?></p>
                    </div>
                    <button wire:click="viewTransaction(<?php echo e($txn->id); ?>)"
                        class="text-blue-600 hover:underline text-sm">
                        View
                    </button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php else: ?>
        <p class="text-gray-600 text-sm">No new transactions.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\transactions\resources\views/livewire/transaction/approver-notifications.blade.php ENDPATH**/ ?>