<div class="max-w-xl mx-auto p-4 bg-white shadow rounded-2xl space-y-4">


    <!--[if BLOCK]><![endif]--><?php if(!$isApprover): ?>
    <div class="flex justify-end">
    <a href="<?php echo e(route('transactions.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Create Transaction</a>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="text-green-600 text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <table class="min-w-full bg-white rounded shadow">
        <thead class="bg-gray-100 text-left text-sm font-medium text-gray-700">
            <tr>
                <th class="px-4 py-2">#</th>
                <th class="px-4 py-2">Summary</th>
                <th class="px-4 py-2">Amount</th>
                <th class="px-4 py-2">Status</th>
                <th class="px-4 py-2">Attachment</th>
                <th class="px-4 py-2">Date</th>
                <!--[if BLOCK]><![endif]--><?php if($isApprover): ?>
                    <th class="px-4 py-2">Actions</th>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t text-sm">
                    <td class="px-4 py-2"><?php echo e($loop->iteration); ?></td>
                    <td class="px-4 py-2"><?php echo e($transaction->summary); ?></td>
                    <td class="px-4 py-2">$<?php echo e(number_format($transaction->amount, 2)); ?></td>
                    <td class="px-4 py-2">
                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'px-2 py-1 rounded-full text-xs',
                            'bg-yellow-200 text-yellow-800' => $transaction->status === 'pending',
                            'bg-green-200 text-green-800' => $transaction->status === 'approved',
                            'bg-red-200 text-red-800' => $transaction->status === 'rejected',
                        ]); ?>">
                            <?php echo e(ucfirst($transaction->status)); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2 text-xs">
                        <!--[if BLOCK]><![endif]--><?php if($transaction->file_attachment): ?>
                            <a href="<?php echo e(asset('storage/' . $transaction->file_attachment)); ?>" target="_blank" class="text-blue-600 underline">
                                View
                            </a>
                        <?php else: ?>
                            <span class="text-gray-500">None</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <td class="px-4 py-2 text-xs text-gray-600">
                        <?php echo e($transaction->created_at->format('M d, Y')); ?>

                    </td>
                    <!--[if BLOCK]><![endif]--><?php if($isApprover): ?>
                        <td class="px-4 py-2 space-x-1">
                            <!--[if BLOCK]><![endif]--><?php if($transaction->status === 'pending'): ?>
                                <button wire:click="approve(<?php echo e($transaction->id); ?>)"
                                    class="bg-green-500 hover:bg-green-600 text-white text-xs px-3 py-1 rounded">
                                    Approve
                                </button>
                                <button wire:click="reject(<?php echo e($transaction->id); ?>)"
                                    class="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1 rounded">
                                    Reject
                                </button>
                            <?php else: ?>
                                <span class="text-gray-500 text-xs">N/A</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-4 py-6 text-center text-gray-500 text-sm">
                        No transactions found.
                    </td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div>
        <?php echo e($transactions->links()); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\transactions\resources\views/livewire/transaction/index.blade.php ENDPATH**/ ?>